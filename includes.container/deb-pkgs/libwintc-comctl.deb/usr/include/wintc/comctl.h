#ifndef __WINTC_COMCTL_H__
#define __WINTC_COMCTL_H__

#include "comctl/animctl.h"
#include "comctl/cpl.h"
#include "comctl/menubind.h"
#include "comctl/style.h"

#endif
