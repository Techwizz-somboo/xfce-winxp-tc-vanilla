/** @file */

#ifndef __COMGTK_REGEX_H__
#define __COMGTK_REGEX_H__

#include <glib.h>

//
// PUBLIC FUNCTIONS
//
const GRegex* wintc_regex_uri_scheme(
    GError** error
);

#endif
