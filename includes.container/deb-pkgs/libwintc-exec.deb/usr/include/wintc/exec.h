#ifndef __WINTC_EXEC_H__
#define __WINTC_EXEC_H__

#include "exec/action.h"
#include "exec/desktop.h"
#include "exec/errors.h"
#include "exec/exec.h"
#include "exec/mime.h"

#endif
