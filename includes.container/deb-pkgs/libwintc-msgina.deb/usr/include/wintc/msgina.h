#ifndef __WINTC_MSGINA_H__
#define __WINTC_MSGINA_H__

#include "msgina/authwnd.h"
#include "msgina/challenge.h"
#include "msgina/exitwnd.h"
#include "msgina/if_authui.h"
#include "msgina/if_sm.h"
#include "msgina/logon.h"
#include "msgina/state.h"
#include "msgina/xdgsm.h"
#include "msgina/xfsm.h"

#endif
