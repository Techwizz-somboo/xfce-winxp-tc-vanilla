#ifndef __WINTC_REGISTRY_H__
#define __WINTC_REGISTRY_H__

#include "registry/reg-dbus.h"
#include "registry/regwrap.h"
#include "registry/variant.h"

#endif
