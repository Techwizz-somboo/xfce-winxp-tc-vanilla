#ifndef __WINTC_SHCOMMON_H__
#define __WINTC_SHCOMMON_H__

#include "shcommon/fs.h"
#include "shcommon/monitor.h"
#include "shcommon/path.h"
#include "shcommon/places.h"

#endif
