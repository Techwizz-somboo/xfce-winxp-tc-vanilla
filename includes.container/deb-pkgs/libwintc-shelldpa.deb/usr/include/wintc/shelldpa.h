#ifndef __WINTC_SHELLDPA_H__
#define __WINTC_SHELLDPA_H__

#include "shelldpa/api.h"
#include "shelldpa/deskwnd.h"

#endif
