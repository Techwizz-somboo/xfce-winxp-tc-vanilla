#ifndef __WINTC_SHELLEXT_H__
#define __WINTC_SHELLEXT_H__

#include "shellext/category.h"
#include "shellext/error.h"
#include "shellext/host.h"
#include "shellext/if_uihost.h"
#include "shellext/if_view.h"
#include "shellext/uictl.h"
#include "shellext/viewitem.h"
#include "shellext/viewops.h"

#endif
