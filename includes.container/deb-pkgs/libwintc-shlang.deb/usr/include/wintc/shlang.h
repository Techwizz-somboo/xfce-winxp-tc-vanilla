#ifndef __WINTC_SHLANG_H__
#define __WINTC_SHLANG_H__

#include "shlang/controls.h"
#include "shlang/domain.h"
#include "shlang/places.h"
#include "shlang/punctuation.h"
#include "shlang/ui.h"

#endif
