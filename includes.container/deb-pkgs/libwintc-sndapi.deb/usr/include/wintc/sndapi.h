#ifndef __WINTC_SNDAPI_H__
#define __WINTC_SNDAPI_H__

#include "sndapi/context.h"
#include "sndapi/output.h"

#endif
