#ifndef __WINTC_SYSCFG_H__
#define __WINTC_SYSCFG_H__

#include "syscfg/enums.h"
#include "syscfg/keys.h"

#endif
