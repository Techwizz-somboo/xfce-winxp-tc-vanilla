#ifndef __SYSCFG_KEYS_H__
#define __SYSCFG_KEYS_H__

#include <glib.h>

//
// PUBLIC CONSTANTS
//
extern const gchar* WINTC_CFG_REGKEY_DESKTOP;

#endif
