#ifndef __WINTC_WINBRAND_H__
#define __WINTC_WINBRAND_H__

#include "winbrand/brand.h"

#endif
